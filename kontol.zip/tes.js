module.exports = {
  testing: function(m) {
    m.reply('yoi');
  }
};
