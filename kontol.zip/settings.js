//Ubah Image/Thumbnail di folder maslent/pplent/maslent.jpg (Cari fotomu Ubah namnya ganti jadi maslent.jpg trus di gantu make pp mu yang baru


//[ ATUR LIMIT DI BAWAH SNDRI OK ]


// Website Api
global.APIs = {
	zenz: 'https://zenzapis.xyz',
}

// Apikey Website Api
global.APIKeys = {
	'https://zenzapis.xyz': 'e98c45547469', // ubah makai apikeymu ambil di websitenya zhawazein
}

global.apizah = 'e98c45547469' // ubah pakai apikeynya zhazawein ok 



const fs = require('fs')
const chalk = require('chalk')
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.autoTyping = false // matikan kalau ga mau mengetik botnya cara matiinya ubah dari true jadi false
//edit aja sesuka hati
global.welcome = `
selamat datang gesss
`
global.left = ` 
bye smoga tenang di sana
`
global.doc6 = 'application/vnd.android.package-archive'



global.submenudonate =`
DONATE MMK SEREBU
DANA :
GOPAY:
DLL
`

global.biogas = 'BOT BY MANZZ XD IS RUNNING'

//convert image jadi url dlu dengan cara
//kirim image ketik !tourl 
global.welcomes ='https://telegra.ph/file/f17b37a3b298054fd8511.jpg' // thumnail welcome
global.keluargc = 'https://telegra.ph/file/cfd0948086c67bf74aaa2.jpg'//thumnabil left





global.sc =`
mediafire paid : 2k/update
free 100+ feature 
`




//==============================\
global.sapi = 'WA MD'
//===============================\\
global.wms = '6285774615156' //wm help Pake nomor yng mau pp nya di jadiin Wm
autoread = true //jangan di ubah
global.footer = 'manzzxd'//ganti
global.pulsa = "6283147641755"//ganti
global.gopay = "----"//ganti
global.dana = "----"//ganti
global.paypal = "---" // biarin aja kalau gaada
global.shopay = "---" // biarin aja kalau gaada
global.saweria = "---" // biarin aja kalau gaada
global.sociabus = "---" // biarin aja kalau gaada
global.bni = "---" // biarin aja kalau gaada
global.bri = "---" // biarin aja kalau gaada
global.bankjatim = "---" // biarin aja kalau gaada
global.jago = "---" // biarin aja kalau gaada
global.neobank = "---" // biarin aja kalau gaada
global.packname = 'MANZZ WA MD'//nama wm
global.footer = '©Manzz XD'//ganti
global.ovo = "-"//ganti
global.ownerlen = "ManzzXD/ManzzBotz"//Ubah
global.owner = ['6285774615156'] //ubh nomor owner hp
global.ownername = "Manzz XD" //ubah
global.ytname = "YT: lenttobs"//ubah
global.socialm = "IG: vlntncptr"//ubah
global.location = "Indonesia, Jawabarat, Banten"//ubah
global.ownernomer = "6285774615156"//ubah nomorhp owner
global.premium = ['6285774615156']//ubah nomor hp premium
global.nomorcs = '6285774615156'//nomormu
global.botname = 'Manzz Botz' //ubah
global.linkz = "Link Gc"//ubah
global.websitex = "yt mu"//ubah
global.botscript = '-'
global.themeemoji = "😿"//ubah
global.packname = "Sticker By"//ubah
global.author = "Made by Manzz"//ubah
global.buyprem = `
LIST HARGA PREMIUM
• ---
• ---
• TMBHN SNDRI CAPEK

~~~~~~~~~~~~~~~~
PAYMENT
DANA :
GOPE :
OVO :
DLL ISI SNDRI :

By Lenttobs
` // <~~ jan di apus ( ` )




global.submenu = `
💬 Sub Menu:
❏ menuai
❏ menuwallpaper
❏ menucerpen
❏ menumaker
❏ menurandomimg
❏ menufun
❏ menuinfo
❏ menuislam
❏ menushort
❏ menuprimbon
❏ menutts
❏ menuowner
❏ menugrub
❏ menudownload
❏ menuother
❏ menutiktok
❏ menuemoji
❏ menuart
❏ menumeme
❏ menutebak
❏ menurandomimgs
❏ menustore
❏ menugoogle
❏ menuprosesingimg
❏ menustalk
❏ menuencode
❏ menuentertainers
❏ menulogo
❏ webmenu
❏ menufilter
❏ menunsfw
❏ menunsfwloli
❏ menudatabase
❏ menuaiimage
❏ menumakequotes
❏ menucreator
❏ menuserti
❏ menumakev2
❏ menunulis

`//jan du haous petik nya
global.submenuai =`
{•------» *AI MENU* «------•}
openai < query >
simi < query >
dalle < query >
dalle2 < Query >
voiceopenai < query >
voicesimi < query >
chichi < query >
dokter < query >
dukun < query >
{•------» *AI MENU* «------•}
`// jan di hapus petiknya

global.submenuwallpaper =`
{•------» *WALLPAPER* «------•}
antikaryawankerja
aesthetic
anime
bike
blackpink
boneka
car
chinese
coffee
cosplay
couplepicture
doggo
gamer
hacking
hijab
indo
japanese
kayes
korean
kpop
lizard
malay
meow
notnot
ppcouple2
profilepicture
pubg
randomboy
randomgirl
rose
ryujin
teknologi
thai
ulzzangboy
ulzzanggirl
wallml
wallpapercyber
wallpaperanimex
wallpaperislami
wallpapermeme
wallpapergamer
wallphone
woof
{•------» *END* «------•}
`

global.submenucerpen =`
{•------» *CERPEN* «------•}
ceritahoror
cerpen-sejarah
cerpen-sedih
cerpen-sastra
cerpen-romantis
cerpen-rohani
cerpen-rindu
cerpen-remaja
cerpen-ramadhan
cerpen-petualangan
cerpen-persahabatan
cerpen-perpisahan
cerpen-perjuangan
cerpen-penyesalan
cerpen-pengorbanan
cerpen-pengalaman
cerpen-pendidikan
cerpen-penantian
cerpen-patahhati
cerpen-olahraga
cerpen-nasionalisme
cerpen-nasihat
cerpen-motifasi
cerpen-misteri
cerpen-mengharukan
cerpen-malaysia
cerpen-liburan
cerpen-kristen
cerpen-korea
cerpen-kisahnyata
cerpen-keluarga
cerpen-kehidupan
cerpen-jepang 
cerpen-inspirstif
cerpen-gokil
cerpen-galau
cerpen-cintasejati
cerpen-cintasegitiga
cerpen-cintasedih
cerpen-cintaromantis
cerpen-cintapertama
cerpen-cintaislami
cerpen-cinta
cerpen-budaya
cerpen-bahasajawa
cerpen-bahasasunda
cerpen-bahasainggris
cerpen-bahasadaerah
cerpen-anak
{•------» *END* «------•}
`

global.submenumaker =`
{•------» *MAKER* «------•}
attp < text >
attp2 < text >
darahmaker < text >
3dmaker < text >
tembokmaker < text >
kertasterbakar < text >
ultahmaker < text >
cardidulfitri < text >
kueultahmaker < text >
amongusmaker < text >
dotamaker < text >
fpsmaker < text >
mlmaker < text >
mlmaker2 < text >
hengkermaker < text >
neonlovemaker < text >
ledmaker < text >
firaunmaker < text >
3draimbowmaker < text >
summermaker < text >
summer2maker < text >
thunder2maker < text >
lightglowmaker < text >
batmanmaker < text >
bussinesmaker < text >
ohnomaker < text >
tololsert < text >
bucinsert < text >
jadianime < text >
nulis < text >
candy < text >
blackpinkneon < text >
deepsea < text >
scifi < text >
fiction < text >
berry < text >
papercut <text>
transformer <text>
neondevil <text>
3davengers <text>
3dstone <text>
3dstone2 <text>
summertime <text>
thunder <text>
window <text>
graffiti <text>
graffitibike <text>
pornhub <text>
glitch <text>
blackpinkart <text>
glitch2 <text>
glitch3 <text>
3dspace <text>
lion <text>
3dneon <text>
greenneon <text>
bokeh <text>
holographic <text>
bear <text>
wolf <text>
joker <text>
dropwater <text>
dropwater2 <text>
thewall <text>
neonlight <text>
natural <text>
carbon <text>
pencil <text>
blackpink2 <text>
neon <text>
neonlight2 <text>
toxic <text>
strawberry <text>
discovery <text>
1917 <text>
lion2 <text>
papercut < text >
transformer < text >
neondevil < text >
3davengers < text >
3dstone < text >
3dstone2 < text >
summertime < text >
thunder < text >
graffiti < text >
graffitibike < text >
pornhub < text >
glitch < text >
blackpinkart < text >
glitch2 < text >
glitch3 < text >
3dspace < text >
lion < text >
3dneon < text >
greenneon < text >
bokeh < text >
holographic < text >
bear < text >
wolf < text >
joker < text >
dropwater < text >
dropwater2 < text >
thewall < text >
neonlight < text >
natural < text >
carbon < text >
pencil < text >
blackpink2 < text >
neon < text >
neonlight2 < text >
toxic < text >
strawberry < text >
discovery < text >
1917 < text >
sci_fi < text >
ancient < text >
fabric < text >
hoorror < text >
whitebear < text >
juice < text >
batman2 < text >
multicolor < text >
wonderful < text >
sketch < text >
marvel < text >
foggy < text >
writing < text >
halloweenfire < text >
halloween < text >
watercolor < text >
classic < text >
{•------» *END* «------•}
`
global.submenurandomimg =`
{•------» *RANDOM IMG* «------•}
animawall [query]
animawall2 [query]
animbite
animblush
animbonk
animbully
animcringe
animcry
animcuddle
animdance
animeawoo
animecuddle
animecry
animeglomp
animehandhold
animehappy
animehighfive
animekiss
animelick
animemegumin
animeneko
animenom
animepat
animepoke
animeslap
animesmile
animesmug
animeslap
animesmug
animewave
animewlp
animewink
animeyeet
avatar
awoo
bully
couplepp
cringe
cry
dance
feed
foxgirl
gecg
gura
handhold
happy
highfive
hug
husbu
kiss
lick
loli-waifu
neko
neko2
nom
pat
randomanime
randomart
randomawloli
randombite
randombts
randombully
shinobu
shota
slap
smile
smug
tickle
waifu
waifu2
wave
{•------» *END* «------•}
`
global.submenufun =`
{•------» *FUN* «------•}
artinama
cekmati
suitwithbot
puisi
namarandom
quotesimage
quotesanimebijak
truth
dare
tictactoe
delttt
tebak [lagu]
math [mode]
suitpvp [tag]
akinator
tebaklagu
say [text]
define [text]
how [text]
when [text]
where [text]
is [text]
what [text]
can [text]
rate [text]
coolcheck [tag]
stupidcheck [tag]
waifucheck [tag]
evilcheck [tag]
dogcheck [tag]
hotcheck [tag]
smartcheck [tag]
uncleancheck [tag]
greatcheck [tag]
beautifulcheck [tag]
awesomecheck [tag]
prettycheck [tag]
lesbiancheck [tag]
gaycheck [tag]
cutecheck [tag]
uglycheck [tag]
hornycheck [tag]
charactercheck [tag]
cerhantu
lovelycheck [tag]
couple
soulmate
hot
sexy
kind
idiot
handsome
beautiful
cute
pretty
lesbian
noob
bastard
foolish
nerd
asshole
gay
smart
stubble
dog
horny
cunt
wibu
noobra
nibba
nibbi
comrade
mumu
rascal
scumbag
nuts
fagot
scoundrel
ditch
dope
gucci
lit
dumbass
crackhead
mf
motherfucker
sucker
fuckboy
playboy
fuckgirl
playgirl
quotes
{•------» *END* «------•}
`
global.submenuinfo =`
{•------» *INFORMASI* «------•}
jalantikus
infogempa
weather
myapikey
cekapikey
infokota
hexcode
cekresi
{•------» *END* «------•}
`

global.menuislam =`
{•------» *ISLAMIC* «------•}
alquran
alquranaudio
kisahnabi
jadwalsholat
asmaulhusna
{•------» *END* «------•}
`
global.submenushort =`
{•------» *SHORT* «------•}
shortlink1
shortlink2
shortlink3
shortlink4
ouolink    
{•------» *END* «------•}
`
global.submenuprimbon =`
{•------» *PRIMBON* «------•}
nomorhoki
artimimpi
ramalanjodoh
ramalanjodohbali
ramalancinta
ramalannasib
suamiistri
kecocokannama
kecocokanpasangan
artinama2
jadianpernikahan
sifatusaha
pekerjaan
rejeki
penyakit
tarot
fengshui 
haribaik
harikeren
harisial
harinaga
arahrejeki
peruntungan
wetonjawa
sifat
keberuntungan
memancing
masasubur
zodiak
shio
{•------» *END* «------•}
`
global.submenutts =`
{•------» *TEXT TO SPECH* «------•}
ttsinglish
ttsind
ttsjpn    
{•------» *END* «------•}
`
global.submenuowner =`
{•------» *OWNER MENU* «------•}
sewa 
listsewa
ceksewa
setpppanjang 
self
addvn
delvn
listvn
public
join [link]
leavegc
setbio
addprem
delprem
bctext [Rawan Banned]
bcimage [Rawan Banned]
bcvideo [RawanBanned]
setbotpp [image]
setthumb [reply img]
setexif
welcome on/off
hijack
block [tag/number]
unblock [tag/number]
{•------» *END* «------•}
`
global.submenugrub =`
{•------» *GROUP MENU* «------•}
grouplink
listadmin
closetime
opentime
grupsetting
ephemeral [option]
setgcpp [image]
setname [text]
setdesc [text]
group 
resetgrouplink
editinfo [option]
menfess [number]
add [user]
kick [reply/tag]
hidetag [text]
tagall [text]
antilinkgc [on/off]
antilinktg [on/off]
antilinktt [on/off]
antilinkytch [on/off]
antilinkytvid [on/off]
antilinkig [on/off]
antilinkfb [on/off]
antilinktwit [on/off]
antilinkremove [on/off]
antilinkdeletekick [on/off]
antivirus [on/off]
antitoxic [on/off]
antiwame [on/off]
nsfw [on/off]
promote [reply/tag]
demote [reply/tag]
react [reply emoji]
vote
devote
upvote
checkvote
delvote
{•------» *END* «------•}
`
global.submenudownload =`
{•------» *DOWNLOAD* «------•}
fotocp (New)
tiktok [url]
tiktokaudio [url]
instagram [url]
spotify [url]
mediafire [url]
ytmp3 [url|quality]
ytmp4 [url|quality]
play [query]
gitclone [repo link]
song [query]
yts [query]
lyrics [query]
gimage [query]
google [query]
anime [query]
pinterest [query]
image [query]
wallpaper [query]
searchno [number]
horoscope [query]
imdb [movie name]
weather [loc name]
genshin [char name]
wikimedia [query]
ytsearch [query]
ringtone [query]
tourl[reply image/video]
toqr [reply text]
toimage [reply stick]
sticker [reply img|gif]
take [reply img|gif|stik]
smeme [reply img]
emoji [emoji]
tovideo [reply img]
togif [reply stick]
tovn [reply aud]
tomp3 [reply vn]
toaudio [reply vid]
ebinary [reply txt]
dbinary [reply txt]
tinyurl [link]
styletext [text]
volume [reply aud]
bass [reply aud]
blown [reply aud]
deep [reply aud]
earrape [reply aud]
fast [reply aud]
fat [reply aud]
nightcore [reply aud]
reverse [reply aud]
robot [reply aud]
slow [reply aud]
smooth [reply aud]
squirrel [reply aud]
{•------» *END* «------•}
`
global.submenuother =`
{•------» *OTHER* «------•}
afk
id
toqr [link]
repeat
readmore [text]
toviewonce
fliptext [text]]
chatinfo
alive
ping
owner
menu
delete
quoted
listpc
listgc
donate
chord
ssweb
myip
request
report [bug]
removebg [reply img]

{•------» *END* «------•}
`
global.submenutiktok =`
{•------» *TIKTOK* «------•}
tiktokgirl	
tiktoknukhty
tiktokpanrika
tiktokkayes
tiktoknotnot
tiktokghea
tiktoksantuy
tiktokbocil
{•------» *END* «------•}
`
global.submenuemoji =`
{•------» *EMOJI* «------•}
instagramemoji
facebookemoji
iphoneemoji
samsungemoji
joyemoji
skypeemoji
twitteremoji
whatsappemoji
microsoftemoji
googleemoji
pediaemoji
microsoftemoji
{•------» *END* «------•}
`
global.submenuart =`
{•------» *ART* «------•}
art
ktpmaker
pornhub
glitch
avanger
space
ninjalogo
wolflogo
stel3d
wallgravity 
{•------» *END* «------•}
`
global.submenumeme =`
{•------» *MEME* «------•}
darkjoke
memeindo
randommeme
{•------» *END* «------•}
`
global.submenutebak =`
{•------» *TEBAK FUN* «------•}
tebak caklontong
tebak lagu
tebak gambar
tebak kata
tebakanime
tebakanime
tebakkabupaten
tebakkimia
tebakkalimat
tebakbendera
tebaklirik
{•------» *END* «------•}
`
global.submenurandomimgs =`
{•------» *RANDOM IMGS* «------•}
bts
exo
elf
loli
neko
waifu
shota
husbu
sagiri
shinobi
husbu
shinobu
mehumin
wallanime                
{•------» *END* «------•}
`
global.submenustore =`
{•------» *STORES* «------•}
liststore
deletemessage 
updatelist
addlist
cekstatus
setstatus
bayar
{•------» *END* «------•}
`
global.submenugoogle =`
{•------» *GOOGLE* «------•}
google < Query >
gimage < Query >
googleimage < Query >
googleimage2 < Query >
{•------» *END* «------•}
`
global.submenuprosesingimg =`
{•----» *PROSESING IMAGE* «----•}
upscaler <reply image>
jadianime <reply image>
jadianime2 <reply image>
jadianime2 <reply image>
jadianime4 <reply image>
upscale <reply Image>
upscale2 < reply img >
remini <reply>
remini2 <reply>
arcane < img/reply>
art < img/reply>
comics < img/reply>

{•------» *END* «------•}
`
global.submenustalk =`
{•------» *STALKING* «------•}
stalknickaov
stalknickchess
stalkbigo
stalkcocofun
stalkig
stalkgithub
stalktwitter
stalktiktok
{•------» *END* «------•}
`
global.submenuencode =`
{•------» *ENDCODE* «------•}
binary < Query >
encodebinary < Query>
ebinary < Query >
dbinary < Query >
codemorse < Query ><
{•------» *END* «------•}
`

global.submenuentertainers =`
{•------» *ENTERTAINERS* «------•}
taugaksih
faktaunik
motivasi
katabijak
{•------» END «------•}
`
global.submenulogo =`
{•------» *LOGO MENU* «------•}
kanekilogo
nekologo
guralogo
lolilogo
nekosad1
{•------» *END* «------•}
`
global.subwebmenu =`
{•------» *WEB MENU* «------•}
webultah
webdeface
websad
websad1
{•------» *WEB MENU* «------•}
`
global.submenufilter =`
{•------» *FILTER MENU* «------•}
pkifilter < reply img >
circlefilter < reply img >
brightfilter < replyimg >
blurfilter < replyimg >
cardfilter < replyimg >
grayscale < replyimg >
gayfilter < replyimg >
contrasfilter < replyimg >
xprofilter < replyimg >
willowfilter < replyimg >
waldenfilter < replyimg >
valenciafilter < replyimg >
toasterfilter < replyimg >
stinsonfilter < replyimg >
slumberfilter < replyimg >
reyesfilter < replyimg >
perpetuafilter < replyimg >
vilefilter < replyimg >
moonfilter < replyimg >
mayfairfilter < replyimg >
kelvinfilter < replyimg >
inkwellfilter < replyimg >
hudsonfilter < replyimg >
brannanfilter < replyimg >
deepfryfilter < replyimg >
facepalmfilter < replyimg >
1977filter < replyimg >
adenfilter < replyimg >
broklinfilter < replyimg >
earlybirdfilter < replyimg >
ginghamfilter < replyimg >
larkfilter < replyimg >
lofifilter < replyimg >
mavenfilter < replyimg >
risefilter < replyimg >
{•------» * MENU* «------•}
`
global.submenunsfw =`

{•------» *NSFW* «------•}
nsfwechi
nsfwechi2
nsfwcum
nsfwclasic
nsfwbj1
nsfwbj2
nsfwbj3
nsfwbj4
nsfwsusugede
nsfwavatar
nsfwthigh
nsfwfetis
nsfwahageo
nsfwanal
nsfwbooty
nsfwarmpits
bokeps (prem)
gifhentai
gifblowjob
hentaivideo
hneko
nwaifu
animespank
trap
gasm
ahegao
ass
bdsm
blowjob
cuckold
cum
milf
eba
ero
femdom
foot
gangbang
glasses
hentai
jahy
manga
masturbation
neko-hentai
neko-hentai2
nsfwloli
orgy
panties
pussy
tentacles
thights
yuri
zettai
{•------» *END* «------•}
`
global.submenunsfwloli =`
{•------» *NSFW LOLI* «------•}
eroholo
eroyuri
erokemo
femdom2   
{•------» *END* «------•}
`

global.menudatabase =`
{•------» *DATABASE MENU* «------•}
addvn
delvn
listvn
addvid
delvid
listvid
addimg
delimg
listimg
{•------» *END* «------•}
`


global.menudatabase =`
{•------» *DATABASE MENU* «------•}
addvn
delvn
listvn
addvid
delvid
listvid
addimg
delimg
listimg
{•------» *END* «------•}
`


global.submenuaiimage=`
{•------» *AI IMAGE* «------•}
aidraw < reply img>
dalle < reply img>
dalle2 < reply img>
dalleanime < reply img>
imgtohororv1 < reply img>
imgtohororv2 < reply img>
imgtohororv3 < reply img>
jadianime < reply img>
jadianime2 < reply img>
recolor < reply img>
imgtoart < reply img>
imgtocosmic < reply img>
imgbluprint < reply img>
renaissance < reply img>
yasuo < reply img> 
blurfilter < reply img>
{•------» *END* «------•}
`

global.makequotes =`
{•------» *MAKE QUOTES* «------•}
makequotes1
makequotes2
{•------» *END* «------•}
`

global.menucreator =`
{•------» *MENU CREATOR* «------•}
botcommand
changemymind
ytcomment
tweetcomment
trumpcomment
qc < reply text ~ text>
qc2 < img color text >
{•------» *END* «------•}
`
global.submenuserti =`
{•------» *MENU SERTI* «------•}
badboyserti
badgirlserti
bucinserti
fuckboyserti
fuckgirlserti
goodboyserti
goodgirlserti
pacarserti
maidoserti
lt3putriserti
lt3putraserti
piagamserti

{•------» *MENU SERTI* «------•}
`
global.menumakerv2 =`
{•------» *MENU MAKERV2* «------•}
textrunning <text>
textrunningstiker <text>
fakechat <reply>
fakechat2 <nama-text-nomor>
{•------» *MENU MAKERV2* «------•} 
`
global.menunulis =`
{•------» *MENU NULIS* «------•} 
magernulis1v2 <text>
magernulis2 <text>
magernulis3 <text>
magernulis4 <text>
magernulis5 <text>
magernulis6 <text>
magernulis7 <text>
magernulis8 <text>
magernulis9 <text>
magernulis10 <text>
magernulis11 <text>
magernulis12 <text>
magernulis13 <text>
magernulis14 <text>
folio1 <text>
folio2 <text>
hvs <text>
{•------» *MENU NULIS* «------•} 
`

//jangan hapus petik `

global.wm = "MANZZ WHATSAAP MD"//ubah Jadi nama wm
global.sessionName = 'session'
global.prefa = ['','!','.','#','&']
global.sp = ''
global.mess = {
    success: 'Piye?!', 
    admin: 'This feature could be used by admins only!',
    botAdmin: 'Bot Must Be Admin First!',
    premime: 'Premium Special Features If You Want to Register Type Rent',
    owner: 'This feature could be used by owner only', 
    group: 'Features Used Only For Groups!',
    private: 'Features Used Only For Private Chat!',
    bot: 'This feature could be used by bot only',
    wait: 'In process...',
    masok: 'MASOKKKKKK', // INI UNTUK COMMAND KETIKA KETIK !PING
    linkm: 'Where is the link?',
    endLimit: 'Upss Limit Kamu sudah habis..Tunggu Waktu menunjukan Pukul 12:00 Limit Anda otomatis akan Di reset!!!',
    nsfw: 'The nsfw feature has not been activated, please contact the admin to activate',
}
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.thum = fs.readFileSync("./Maslent/pplent/maslent.jpg")
global.log0 = fs.readFileSync("./Maslent/pplent/maslent.jpg")
global.err4r = fs.readFileSync("./Maslent/pplent/maslent.jpg")
global.thumb = fs.readFileSync("./Maslent/pplent/maslent.jpg")
global.limitawal = { //limit ges
    premium: "UNLIMITED",
    free: 10// atur limitinya sesuka hati
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
